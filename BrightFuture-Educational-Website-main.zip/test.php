
<?php
require_once __DIR__ . '/config/app.php';

header('Content-Type: text/plain; charset=utf-8');

echo "Website: " . APP_NAME . PHP_EOL;

echo "Base URL: " . BASE_URL . PHP_EOL;

echo "Base Path: " . BASE_PATH . PHP_EOL;

echo "Timezone: " . date_default_timezone_get()
    . PHP_EOL;

echo "Session: " . session_status()
    . PHP_EOL;

echo "Student dashboard: "
    . dashboard_url(ROLE_STUDENT)
    . PHP_EOL;

echo "Teacher dashboard: "
    . dashboard_url(ROLE_TEACHER)
    . PHP_EOL;

echo "Admin dashboard: "
    . dashboard_url(ROLE_ADMIN)
    . PHP_EOL;
